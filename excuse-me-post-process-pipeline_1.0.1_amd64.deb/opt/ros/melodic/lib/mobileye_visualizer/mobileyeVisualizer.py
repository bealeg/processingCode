#!/usr/bin/python

import rospy
from geometry_msgs.msg import Point, PointStamped, Pose, PoseStamped, Quaternion
from visualization_msgs.msg import *
from mobileye_msgs.msg import *
import tf2_ros
import tf2_geometry_msgs

class mobileyeVisualizer(object):
    frame_id = None
    markers = None
    transform = None

    def __init__(self):
        rospy.init_node('mobileye_visualizer', anonymous=False)

        # Parameters
        self.frame_id = rospy.get_param('~frame_id', 'mobileye')
        self.target_frame_id = rospy.get_param('~target_frame_id', 'base_link')
        self.hz = rospy.get_param('~hz', 40.0)
        self.rate = rospy.Rate(float(self.hz)) 
 
        # Subscribers
        rospy.Subscriber('Obstacles', Obstacle, self.updateObstacles)
        rospy.Subscriber('RoadGeometry', RoadGeometry, self.updateRoadGeometry)
        rospy.Subscriber('NextLane', NextLane, self.updateNextLane)
        rospy.Subscriber('TSRs', TSRs, self.updateTSRs)

        # Publisher
        self.obstaclesPub = rospy.Publisher('Obstacles_markers', MarkerArray, queue_size=10)
        self.roadGeometryPub = rospy.Publisher('RoadGeometry_markers', MarkerArray, queue_size=10)
        self.nextLanePub = rospy.Publisher('NextLane_markers', MarkerArray, queue_size=10)
        self.tsrsPub = rospy.Publisher('TSRs_markers', MarkerArray, queue_size=10)

        # Listen for transforms
        self.tfBuffer = tf2_ros.Buffer()
        self.listener = tf2_ros.TransformListener(self.tfBuffer)

    def getTransform(self):
        try:
            if self.tfBuffer.can_transform(self.frame_id,self.target_frame_id,rospy.Time.now()):
                self.transform = self.tfBuffer.lookup_transform(self.target_frame_id,self.frame_id,rospy.Time.now())
                print("Got mobileye obstacles to base link transform!")
        except Exception as ex:
            print("getTransform:",ex)

    def updateObstacles(self, msg):
        if msg is not None:
            self.markers = MarkerArray()
            for i in range(0, len(msg.objects)):
                obj = msg.objects[i]
                if obj.valid == 0:
                    continue
                if not self.transform is None:
                    color = [1, 1, 1, 0.5]
                    self.markers.markers.append(
                        self.toCube(obj.id, obj.header, obj.x_pos, obj.y_pos, 0.0, obj.length, obj.width, 1.46, color)
                    )
            self.obstaclesPub.publish(self.markers)

    def updateRoadGeometry(self, msg):
        if msg is not None:
            self.markers = MarkerArray()
            if self.transform is not None:
                color = [1, 0, 0, 1]
                if msg.left_quality == 1:
                    color = [0.7, 0.3, 0, 1]
                elif msg.left_quality == 2:
                    color = [0.3, 0.7, 0, 1]
                elif msg.left_quality == 3:
                    color = [0, 1, 0, 1]
                path = self.toLineStrip(0, msg.header, msg.left_C0, msg.left_C1, msg.left_C2, msg.left_C3, color)
                self.markers.markers.append(path)
                color = [1, 0, 0, 1]
                if msg.right_quality == 1:
                    color = [0.7, 0.3, 0, 1]
                elif msg.right_quality == 2:
                    color = [0.3, 0.7, 0, 1]
                elif msg.right_quality == 3:
                    color = [0, 1, 0, 1]
                path = self.toLineStrip(1, msg.header, msg.right_C0, msg.right_C1, msg.right_C2, msg.right_C3, color)
                self.markers.markers.append(path)
            self.roadGeometryPub.publish(self.markers)

    def updateNextLane(self, msg):
        if msg is not None:
            self.markers = MarkerArray()
            for i in range(0, len(msg.nextlaneobjects)):
                obj = msg.nextlaneobjects[i]
                if not self.transform is None:
                    if obj.left_lane_type == 1:
                        color = [0, 1, 0, 1]
                        path = self.toLineStrip((i*2)+0, obj.header, obj.left_C0, obj.left_C1, obj.left_C2, obj.left_C3, color)
                        self.markers.markers.append(path)
                    if obj.right_lane_type == 1:
                        color = [0, 1, 0, 1]
                        path = self.toLineStrip((i*2)+1, obj.header, obj.right_C0, obj.right_C1, obj.right_C2, obj.right_C3, color)
                        self.markers.markers.append(path)
            self.nextLanePub.publish(self.markers)

    def updateTSRs(self, msg):
        if msg is not None:
            self.markers = MarkerArray()
            for i in range(0, len(msg.tsrs)):
                tsr = msg.tsrs[i]
                if not self.transform is None:
                    color = [1, 1, 1, 0.5]
                    self.markers.markers.append(
                        self.toCube(i, tsr.header, tsr.pos_x, tsr.pos_y, tsr.pos_z, 0.02, 0.61, 0.76, color)
                    )
            self.tsrsPub.publish(self.markers)

    def transformPoint(self, pointStamped):
        new_point = None
        if self.transform is not None:
            try:
                new_point = tf2_geometry_msgs.do_transform_point(pointStamped, self.transform)
                new_point.point.z = 0
            except tf2_ros.TypeException as ex:
                print("transformPoint:",ex.errstr)
        return new_point.point

    def toCube(self, id, header, x, y, z, length=1.0, width=1.0, height=1.0, color=[1, 0, 0, 1]):

        pointStamped = PointStamped()
        pointStamped.header = header
        pointStamped.point.x = x
        pointStamped.point.y = y
        pointStamped.point.z = z

        tmp_point = self.transformPoint(pointStamped)
        if tmp_point is None:
            print("Point transform returned None")
            return None

        m = Marker()
        m.header.frame_id = self.target_frame_id
        m.header.stamp = header.stamp
        m.id = id
        m.type = Marker.CUBE
        m.action = Marker.ADD
        m.pose.position.x = tmp_point.x + (length / 2.0)
        m.pose.position.y = tmp_point.y
        m.pose.position.z = tmp_point.z + (height / 2.0)
        m.pose.orientation.w = 1.0
        m.scale.x = length
        m.scale.y = width
        m.scale.z = height
        m.color.r = color[0]
        m.color.g = color[1]
        m.color.b = color[2]
        m.color.a = color[3]
        m.lifetime = rospy.Duration(1.0)

        return m

    def toLineStrip(self, id, header, C0, C1, C2, C3, color=[1, 0, 0, 1]):

        m = Marker()
        m.header.frame_id = self.target_frame_id
        m.header.stamp = header.stamp
        m.ns = ''
        m.id = id
        m.type = Marker.LINE_STRIP
        m.action = Marker.ADD
        m.pose.position.x = 0
        m.pose.position.y = 0
        m.pose.position.z = 0
        m.pose.orientation.x = 0
        m.pose.orientation.y = 0
        m.pose.orientation.z = 0
        m.pose.orientation.w = 1
        m.scale.x = 0.1
        m.scale.y = 0.1
        m.scale.z = 0.1
        m.color.r = color[0]
        m.color.g = color[1]
        m.color.b = color[2]
        m.color.a = color[3]
        m.lifetime = rospy.Duration(1.0)

        x = 0.0
        while x <= 100.0:

            pointStamped = PointStamped()
            pointStamped.header = header
            pointStamped.point.x = x
            pointStamped.point.y = -1.0 * ((C3 * pow(x, 3.0)) + (C2 * pow(x, 2.0)) + (C1 * x) + (C0))
            pointStamped.point.z = 0.0

            tmp_point = self.transformPoint(pointStamped)
            if tmp_point is None:
                print("Point transform returned None")
                return None

            m.points.append(tmp_point)

            x += 1.0

        return m

    def run(self):
        while not rospy.is_shutdown():
            if self.transform is None:
                self.getTransform()
            self.rate.sleep()

if __name__ == '__main__':
    try:
        node = mobileyeVisualizer()
        node.run()
    except Exception as ex: 
       print(ex) 
 
