// Auto-generated. Do not edit!

// (in-package mobileye_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class ObstacleObject {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.id = null;
      this.age = null;
      this.valid = null;
      this.status = null;
      this.lane_status = null;
      this.lane = null;
      this.type = null;
      this.brake_light = null;
      this.blinker = null;
      this.cipv = null;
      this.replaced = null;
      this.x_pos = null;
      this.y_pos = null;
      this.x_vel = null;
      this.angle_rate = null;
      this.scale_change = null;
      this.x_accel = null;
      this.angle = null;
      this.length = null;
      this.width = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('id')) {
        this.id = initObj.id
      }
      else {
        this.id = 0;
      }
      if (initObj.hasOwnProperty('age')) {
        this.age = initObj.age
      }
      else {
        this.age = 0;
      }
      if (initObj.hasOwnProperty('valid')) {
        this.valid = initObj.valid
      }
      else {
        this.valid = 0;
      }
      if (initObj.hasOwnProperty('status')) {
        this.status = initObj.status
      }
      else {
        this.status = 0;
      }
      if (initObj.hasOwnProperty('lane_status')) {
        this.lane_status = initObj.lane_status
      }
      else {
        this.lane_status = 0;
      }
      if (initObj.hasOwnProperty('lane')) {
        this.lane = initObj.lane
      }
      else {
        this.lane = 0;
      }
      if (initObj.hasOwnProperty('type')) {
        this.type = initObj.type
      }
      else {
        this.type = 0;
      }
      if (initObj.hasOwnProperty('brake_light')) {
        this.brake_light = initObj.brake_light
      }
      else {
        this.brake_light = 0;
      }
      if (initObj.hasOwnProperty('blinker')) {
        this.blinker = initObj.blinker
      }
      else {
        this.blinker = 0;
      }
      if (initObj.hasOwnProperty('cipv')) {
        this.cipv = initObj.cipv
      }
      else {
        this.cipv = 0;
      }
      if (initObj.hasOwnProperty('replaced')) {
        this.replaced = initObj.replaced
      }
      else {
        this.replaced = 0;
      }
      if (initObj.hasOwnProperty('x_pos')) {
        this.x_pos = initObj.x_pos
      }
      else {
        this.x_pos = 0.0;
      }
      if (initObj.hasOwnProperty('y_pos')) {
        this.y_pos = initObj.y_pos
      }
      else {
        this.y_pos = 0.0;
      }
      if (initObj.hasOwnProperty('x_vel')) {
        this.x_vel = initObj.x_vel
      }
      else {
        this.x_vel = 0.0;
      }
      if (initObj.hasOwnProperty('angle_rate')) {
        this.angle_rate = initObj.angle_rate
      }
      else {
        this.angle_rate = 0.0;
      }
      if (initObj.hasOwnProperty('scale_change')) {
        this.scale_change = initObj.scale_change
      }
      else {
        this.scale_change = 0.0;
      }
      if (initObj.hasOwnProperty('x_accel')) {
        this.x_accel = initObj.x_accel
      }
      else {
        this.x_accel = 0.0;
      }
      if (initObj.hasOwnProperty('angle')) {
        this.angle = initObj.angle
      }
      else {
        this.angle = 0.0;
      }
      if (initObj.hasOwnProperty('length')) {
        this.length = initObj.length
      }
      else {
        this.length = 0.0;
      }
      if (initObj.hasOwnProperty('width')) {
        this.width = initObj.width
      }
      else {
        this.width = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type ObstacleObject
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [id]
    bufferOffset = _serializer.uint8(obj.id, buffer, bufferOffset);
    // Serialize message field [age]
    bufferOffset = _serializer.uint8(obj.age, buffer, bufferOffset);
    // Serialize message field [valid]
    bufferOffset = _serializer.uint8(obj.valid, buffer, bufferOffset);
    // Serialize message field [status]
    bufferOffset = _serializer.uint8(obj.status, buffer, bufferOffset);
    // Serialize message field [lane_status]
    bufferOffset = _serializer.uint8(obj.lane_status, buffer, bufferOffset);
    // Serialize message field [lane]
    bufferOffset = _serializer.uint8(obj.lane, buffer, bufferOffset);
    // Serialize message field [type]
    bufferOffset = _serializer.uint8(obj.type, buffer, bufferOffset);
    // Serialize message field [brake_light]
    bufferOffset = _serializer.uint8(obj.brake_light, buffer, bufferOffset);
    // Serialize message field [blinker]
    bufferOffset = _serializer.uint8(obj.blinker, buffer, bufferOffset);
    // Serialize message field [cipv]
    bufferOffset = _serializer.uint8(obj.cipv, buffer, bufferOffset);
    // Serialize message field [replaced]
    bufferOffset = _serializer.uint8(obj.replaced, buffer, bufferOffset);
    // Serialize message field [x_pos]
    bufferOffset = _serializer.float64(obj.x_pos, buffer, bufferOffset);
    // Serialize message field [y_pos]
    bufferOffset = _serializer.float64(obj.y_pos, buffer, bufferOffset);
    // Serialize message field [x_vel]
    bufferOffset = _serializer.float64(obj.x_vel, buffer, bufferOffset);
    // Serialize message field [angle_rate]
    bufferOffset = _serializer.float64(obj.angle_rate, buffer, bufferOffset);
    // Serialize message field [scale_change]
    bufferOffset = _serializer.float64(obj.scale_change, buffer, bufferOffset);
    // Serialize message field [x_accel]
    bufferOffset = _serializer.float64(obj.x_accel, buffer, bufferOffset);
    // Serialize message field [angle]
    bufferOffset = _serializer.float64(obj.angle, buffer, bufferOffset);
    // Serialize message field [length]
    bufferOffset = _serializer.float64(obj.length, buffer, bufferOffset);
    // Serialize message field [width]
    bufferOffset = _serializer.float64(obj.width, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type ObstacleObject
    let len;
    let data = new ObstacleObject(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [id]
    data.id = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [age]
    data.age = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [valid]
    data.valid = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [status]
    data.status = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [lane_status]
    data.lane_status = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [lane]
    data.lane = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [type]
    data.type = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [brake_light]
    data.brake_light = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [blinker]
    data.blinker = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [cipv]
    data.cipv = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [replaced]
    data.replaced = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [x_pos]
    data.x_pos = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [y_pos]
    data.y_pos = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [x_vel]
    data.x_vel = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [angle_rate]
    data.angle_rate = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [scale_change]
    data.scale_change = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [x_accel]
    data.x_accel = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [angle]
    data.angle = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [length]
    data.length = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [width]
    data.width = _deserializer.float64(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    return length + 83;
  }

  static datatype() {
    // Returns string type for a message object
    return 'mobileye_msgs/ObstacleObject';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '371a86a08770e34264ebd7e20d779179';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    #Message Header
    std_msgs/Header header
    
    uint8 id # id
    uint8 age # in frames 0 - 254, 254 is oldest
    uint8 valid # 1=new valid, 2=older valid
    uint8 status # 0=undefined,1=standing,2=stopped,3=moving,4=oncoming,5=parked
    uint8 lane_status # 0=undefined,1=in_host_lane,2=out_host_lane,3=cut_in,4=cut_out
    uint8 lane #0=not_assigned,1=ego_lane,2=next_lane(left or right), or next_next_lane,3=invalid
    uint8 type # 0=vehicle,1=truck,2=bike,3=ped,4=bicycle
    uint8 brake_light #0=off,1=on
    uint8 blinker # 0=unavailable,1=off,2=left,3=right,4=both
    uint8 cipv #closest_in_path_vehicle 0=no,1=yes
    uint8 replaced #0=not_replaced_in_this_frame,1=replaced_in_this_frame
    
    float64 x_pos #m
    float64 y_pos #m
    float64 x_vel #m/s
    
    float64 angle_rate #deg/s
    float64 scale_change #pix/s
    float64 x_accel #m/s^2
    
    float64 angle #deg
    
    
    float64 length #m
    float64 width #m
    
    
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    string frame_id
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new ObstacleObject(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.id !== undefined) {
      resolved.id = msg.id;
    }
    else {
      resolved.id = 0
    }

    if (msg.age !== undefined) {
      resolved.age = msg.age;
    }
    else {
      resolved.age = 0
    }

    if (msg.valid !== undefined) {
      resolved.valid = msg.valid;
    }
    else {
      resolved.valid = 0
    }

    if (msg.status !== undefined) {
      resolved.status = msg.status;
    }
    else {
      resolved.status = 0
    }

    if (msg.lane_status !== undefined) {
      resolved.lane_status = msg.lane_status;
    }
    else {
      resolved.lane_status = 0
    }

    if (msg.lane !== undefined) {
      resolved.lane = msg.lane;
    }
    else {
      resolved.lane = 0
    }

    if (msg.type !== undefined) {
      resolved.type = msg.type;
    }
    else {
      resolved.type = 0
    }

    if (msg.brake_light !== undefined) {
      resolved.brake_light = msg.brake_light;
    }
    else {
      resolved.brake_light = 0
    }

    if (msg.blinker !== undefined) {
      resolved.blinker = msg.blinker;
    }
    else {
      resolved.blinker = 0
    }

    if (msg.cipv !== undefined) {
      resolved.cipv = msg.cipv;
    }
    else {
      resolved.cipv = 0
    }

    if (msg.replaced !== undefined) {
      resolved.replaced = msg.replaced;
    }
    else {
      resolved.replaced = 0
    }

    if (msg.x_pos !== undefined) {
      resolved.x_pos = msg.x_pos;
    }
    else {
      resolved.x_pos = 0.0
    }

    if (msg.y_pos !== undefined) {
      resolved.y_pos = msg.y_pos;
    }
    else {
      resolved.y_pos = 0.0
    }

    if (msg.x_vel !== undefined) {
      resolved.x_vel = msg.x_vel;
    }
    else {
      resolved.x_vel = 0.0
    }

    if (msg.angle_rate !== undefined) {
      resolved.angle_rate = msg.angle_rate;
    }
    else {
      resolved.angle_rate = 0.0
    }

    if (msg.scale_change !== undefined) {
      resolved.scale_change = msg.scale_change;
    }
    else {
      resolved.scale_change = 0.0
    }

    if (msg.x_accel !== undefined) {
      resolved.x_accel = msg.x_accel;
    }
    else {
      resolved.x_accel = 0.0
    }

    if (msg.angle !== undefined) {
      resolved.angle = msg.angle;
    }
    else {
      resolved.angle = 0.0
    }

    if (msg.length !== undefined) {
      resolved.length = msg.length;
    }
    else {
      resolved.length = 0.0
    }

    if (msg.width !== undefined) {
      resolved.width = msg.width;
    }
    else {
      resolved.width = 0.0
    }

    return resolved;
    }
};

module.exports = ObstacleObject;
