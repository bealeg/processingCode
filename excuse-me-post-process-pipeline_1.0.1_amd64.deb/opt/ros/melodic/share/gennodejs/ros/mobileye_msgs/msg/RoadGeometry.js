// Auto-generated. Do not edit!

// (in-package mobileye_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class RoadGeometry {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.left_C0 = null;
      this.left_C1 = null;
      this.left_C2 = null;
      this.left_C3 = null;
      this.left_quality = null;
      this.left_cross = null;
      this.right_C0 = null;
      this.right_C1 = null;
      this.right_C2 = null;
      this.right_C3 = null;
      this.right_quality = null;
      this.right_cross = null;
      this.fail_safe = null;
      this.maintenance = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('left_C0')) {
        this.left_C0 = initObj.left_C0
      }
      else {
        this.left_C0 = 0.0;
      }
      if (initObj.hasOwnProperty('left_C1')) {
        this.left_C1 = initObj.left_C1
      }
      else {
        this.left_C1 = 0.0;
      }
      if (initObj.hasOwnProperty('left_C2')) {
        this.left_C2 = initObj.left_C2
      }
      else {
        this.left_C2 = 0.0;
      }
      if (initObj.hasOwnProperty('left_C3')) {
        this.left_C3 = initObj.left_C3
      }
      else {
        this.left_C3 = 0.0;
      }
      if (initObj.hasOwnProperty('left_quality')) {
        this.left_quality = initObj.left_quality
      }
      else {
        this.left_quality = 0;
      }
      if (initObj.hasOwnProperty('left_cross')) {
        this.left_cross = initObj.left_cross
      }
      else {
        this.left_cross = 0;
      }
      if (initObj.hasOwnProperty('right_C0')) {
        this.right_C0 = initObj.right_C0
      }
      else {
        this.right_C0 = 0.0;
      }
      if (initObj.hasOwnProperty('right_C1')) {
        this.right_C1 = initObj.right_C1
      }
      else {
        this.right_C1 = 0.0;
      }
      if (initObj.hasOwnProperty('right_C2')) {
        this.right_C2 = initObj.right_C2
      }
      else {
        this.right_C2 = 0.0;
      }
      if (initObj.hasOwnProperty('right_C3')) {
        this.right_C3 = initObj.right_C3
      }
      else {
        this.right_C3 = 0.0;
      }
      if (initObj.hasOwnProperty('right_quality')) {
        this.right_quality = initObj.right_quality
      }
      else {
        this.right_quality = 0;
      }
      if (initObj.hasOwnProperty('right_cross')) {
        this.right_cross = initObj.right_cross
      }
      else {
        this.right_cross = 0;
      }
      if (initObj.hasOwnProperty('fail_safe')) {
        this.fail_safe = initObj.fail_safe
      }
      else {
        this.fail_safe = false;
      }
      if (initObj.hasOwnProperty('maintenance')) {
        this.maintenance = initObj.maintenance
      }
      else {
        this.maintenance = false;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type RoadGeometry
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [left_C0]
    bufferOffset = _serializer.float64(obj.left_C0, buffer, bufferOffset);
    // Serialize message field [left_C1]
    bufferOffset = _serializer.float64(obj.left_C1, buffer, bufferOffset);
    // Serialize message field [left_C2]
    bufferOffset = _serializer.float64(obj.left_C2, buffer, bufferOffset);
    // Serialize message field [left_C3]
    bufferOffset = _serializer.float64(obj.left_C3, buffer, bufferOffset);
    // Serialize message field [left_quality]
    bufferOffset = _serializer.uint8(obj.left_quality, buffer, bufferOffset);
    // Serialize message field [left_cross]
    bufferOffset = _serializer.uint8(obj.left_cross, buffer, bufferOffset);
    // Serialize message field [right_C0]
    bufferOffset = _serializer.float64(obj.right_C0, buffer, bufferOffset);
    // Serialize message field [right_C1]
    bufferOffset = _serializer.float64(obj.right_C1, buffer, bufferOffset);
    // Serialize message field [right_C2]
    bufferOffset = _serializer.float64(obj.right_C2, buffer, bufferOffset);
    // Serialize message field [right_C3]
    bufferOffset = _serializer.float64(obj.right_C3, buffer, bufferOffset);
    // Serialize message field [right_quality]
    bufferOffset = _serializer.uint8(obj.right_quality, buffer, bufferOffset);
    // Serialize message field [right_cross]
    bufferOffset = _serializer.uint8(obj.right_cross, buffer, bufferOffset);
    // Serialize message field [fail_safe]
    bufferOffset = _serializer.bool(obj.fail_safe, buffer, bufferOffset);
    // Serialize message field [maintenance]
    bufferOffset = _serializer.bool(obj.maintenance, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type RoadGeometry
    let len;
    let data = new RoadGeometry(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [left_C0]
    data.left_C0 = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [left_C1]
    data.left_C1 = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [left_C2]
    data.left_C2 = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [left_C3]
    data.left_C3 = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [left_quality]
    data.left_quality = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [left_cross]
    data.left_cross = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [right_C0]
    data.right_C0 = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [right_C1]
    data.right_C1 = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [right_C2]
    data.right_C2 = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [right_C3]
    data.right_C3 = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [right_quality]
    data.right_quality = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [right_cross]
    data.right_cross = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [fail_safe]
    data.fail_safe = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [maintenance]
    data.maintenance = _deserializer.bool(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    return length + 70;
  }

  static datatype() {
    // Returns string type for a message object
    return 'mobileye_msgs/RoadGeometry';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '1ca9944ec006cc6aec01495925191322';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    #Message Header
    std_msgs/Header header
    
    float64 left_C0
    float64 left_C1
    float64 left_C2
    float64 left_C3
    uint8 left_quality 
    uint8 left_cross
    
    float64 right_C0
    float64 right_C1
    float64 right_C2
    float64 right_C3
    uint8 right_quality 
    uint8 right_cross
    
    bool fail_safe
    bool maintenance
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    string frame_id
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new RoadGeometry(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.left_C0 !== undefined) {
      resolved.left_C0 = msg.left_C0;
    }
    else {
      resolved.left_C0 = 0.0
    }

    if (msg.left_C1 !== undefined) {
      resolved.left_C1 = msg.left_C1;
    }
    else {
      resolved.left_C1 = 0.0
    }

    if (msg.left_C2 !== undefined) {
      resolved.left_C2 = msg.left_C2;
    }
    else {
      resolved.left_C2 = 0.0
    }

    if (msg.left_C3 !== undefined) {
      resolved.left_C3 = msg.left_C3;
    }
    else {
      resolved.left_C3 = 0.0
    }

    if (msg.left_quality !== undefined) {
      resolved.left_quality = msg.left_quality;
    }
    else {
      resolved.left_quality = 0
    }

    if (msg.left_cross !== undefined) {
      resolved.left_cross = msg.left_cross;
    }
    else {
      resolved.left_cross = 0
    }

    if (msg.right_C0 !== undefined) {
      resolved.right_C0 = msg.right_C0;
    }
    else {
      resolved.right_C0 = 0.0
    }

    if (msg.right_C1 !== undefined) {
      resolved.right_C1 = msg.right_C1;
    }
    else {
      resolved.right_C1 = 0.0
    }

    if (msg.right_C2 !== undefined) {
      resolved.right_C2 = msg.right_C2;
    }
    else {
      resolved.right_C2 = 0.0
    }

    if (msg.right_C3 !== undefined) {
      resolved.right_C3 = msg.right_C3;
    }
    else {
      resolved.right_C3 = 0.0
    }

    if (msg.right_quality !== undefined) {
      resolved.right_quality = msg.right_quality;
    }
    else {
      resolved.right_quality = 0
    }

    if (msg.right_cross !== undefined) {
      resolved.right_cross = msg.right_cross;
    }
    else {
      resolved.right_cross = 0
    }

    if (msg.fail_safe !== undefined) {
      resolved.fail_safe = msg.fail_safe;
    }
    else {
      resolved.fail_safe = false
    }

    if (msg.maintenance !== undefined) {
      resolved.maintenance = msg.maintenance;
    }
    else {
      resolved.maintenance = false
    }

    return resolved;
    }
};

module.exports = RoadGeometry;
