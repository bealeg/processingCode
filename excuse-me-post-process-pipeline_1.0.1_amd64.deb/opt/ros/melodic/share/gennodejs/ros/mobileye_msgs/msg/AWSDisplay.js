// Auto-generated. Do not edit!

// (in-package mobileye_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class AWSDisplay {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.night_time = null;
      this.dusk_time = null;
      this.sound_type = null;
      this.headway_valid = null;
      this.headway = null;
      this.lanes_on = null;
      this.left_ldw_on = null;
      this.right_ldw_on = null;
      this.fcw_on = null;
      this.left_cross = null;
      this.right_cross = null;
      this.maintenance = null;
      this.fail_safe = null;
      this.ped_fcw = null;
      this.ped_in_dz = null;
      this.warning_level = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('night_time')) {
        this.night_time = initObj.night_time
      }
      else {
        this.night_time = 0;
      }
      if (initObj.hasOwnProperty('dusk_time')) {
        this.dusk_time = initObj.dusk_time
      }
      else {
        this.dusk_time = 0;
      }
      if (initObj.hasOwnProperty('sound_type')) {
        this.sound_type = initObj.sound_type
      }
      else {
        this.sound_type = 0;
      }
      if (initObj.hasOwnProperty('headway_valid')) {
        this.headway_valid = initObj.headway_valid
      }
      else {
        this.headway_valid = 0;
      }
      if (initObj.hasOwnProperty('headway')) {
        this.headway = initObj.headway
      }
      else {
        this.headway = 0.0;
      }
      if (initObj.hasOwnProperty('lanes_on')) {
        this.lanes_on = initObj.lanes_on
      }
      else {
        this.lanes_on = 0;
      }
      if (initObj.hasOwnProperty('left_ldw_on')) {
        this.left_ldw_on = initObj.left_ldw_on
      }
      else {
        this.left_ldw_on = 0;
      }
      if (initObj.hasOwnProperty('right_ldw_on')) {
        this.right_ldw_on = initObj.right_ldw_on
      }
      else {
        this.right_ldw_on = 0;
      }
      if (initObj.hasOwnProperty('fcw_on')) {
        this.fcw_on = initObj.fcw_on
      }
      else {
        this.fcw_on = 0;
      }
      if (initObj.hasOwnProperty('left_cross')) {
        this.left_cross = initObj.left_cross
      }
      else {
        this.left_cross = 0;
      }
      if (initObj.hasOwnProperty('right_cross')) {
        this.right_cross = initObj.right_cross
      }
      else {
        this.right_cross = 0;
      }
      if (initObj.hasOwnProperty('maintenance')) {
        this.maintenance = initObj.maintenance
      }
      else {
        this.maintenance = 0;
      }
      if (initObj.hasOwnProperty('fail_safe')) {
        this.fail_safe = initObj.fail_safe
      }
      else {
        this.fail_safe = 0;
      }
      if (initObj.hasOwnProperty('ped_fcw')) {
        this.ped_fcw = initObj.ped_fcw
      }
      else {
        this.ped_fcw = 0;
      }
      if (initObj.hasOwnProperty('ped_in_dz')) {
        this.ped_in_dz = initObj.ped_in_dz
      }
      else {
        this.ped_in_dz = 0;
      }
      if (initObj.hasOwnProperty('warning_level')) {
        this.warning_level = initObj.warning_level
      }
      else {
        this.warning_level = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type AWSDisplay
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [night_time]
    bufferOffset = _serializer.uint8(obj.night_time, buffer, bufferOffset);
    // Serialize message field [dusk_time]
    bufferOffset = _serializer.uint8(obj.dusk_time, buffer, bufferOffset);
    // Serialize message field [sound_type]
    bufferOffset = _serializer.uint8(obj.sound_type, buffer, bufferOffset);
    // Serialize message field [headway_valid]
    bufferOffset = _serializer.uint8(obj.headway_valid, buffer, bufferOffset);
    // Serialize message field [headway]
    bufferOffset = _serializer.float32(obj.headway, buffer, bufferOffset);
    // Serialize message field [lanes_on]
    bufferOffset = _serializer.uint8(obj.lanes_on, buffer, bufferOffset);
    // Serialize message field [left_ldw_on]
    bufferOffset = _serializer.uint8(obj.left_ldw_on, buffer, bufferOffset);
    // Serialize message field [right_ldw_on]
    bufferOffset = _serializer.uint8(obj.right_ldw_on, buffer, bufferOffset);
    // Serialize message field [fcw_on]
    bufferOffset = _serializer.uint8(obj.fcw_on, buffer, bufferOffset);
    // Serialize message field [left_cross]
    bufferOffset = _serializer.uint8(obj.left_cross, buffer, bufferOffset);
    // Serialize message field [right_cross]
    bufferOffset = _serializer.uint8(obj.right_cross, buffer, bufferOffset);
    // Serialize message field [maintenance]
    bufferOffset = _serializer.uint8(obj.maintenance, buffer, bufferOffset);
    // Serialize message field [fail_safe]
    bufferOffset = _serializer.uint8(obj.fail_safe, buffer, bufferOffset);
    // Serialize message field [ped_fcw]
    bufferOffset = _serializer.uint8(obj.ped_fcw, buffer, bufferOffset);
    // Serialize message field [ped_in_dz]
    bufferOffset = _serializer.uint8(obj.ped_in_dz, buffer, bufferOffset);
    // Serialize message field [warning_level]
    bufferOffset = _serializer.uint8(obj.warning_level, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type AWSDisplay
    let len;
    let data = new AWSDisplay(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [night_time]
    data.night_time = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [dusk_time]
    data.dusk_time = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [sound_type]
    data.sound_type = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [headway_valid]
    data.headway_valid = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [headway]
    data.headway = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [lanes_on]
    data.lanes_on = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [left_ldw_on]
    data.left_ldw_on = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [right_ldw_on]
    data.right_ldw_on = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [fcw_on]
    data.fcw_on = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [left_cross]
    data.left_cross = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [right_cross]
    data.right_cross = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [maintenance]
    data.maintenance = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [fail_safe]
    data.fail_safe = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [ped_fcw]
    data.ped_fcw = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [ped_in_dz]
    data.ped_in_dz = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [warning_level]
    data.warning_level = _deserializer.uint8(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    return length + 19;
  }

  static datatype() {
    // Returns string type for a message object
    return 'mobileye_msgs/AWSDisplay';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '636cd4c8cf173874f6cf4e2728d9f3de';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    #Message Header
    std_msgs/Header header
    
    uint8 night_time
    uint8 dusk_time
    uint8 sound_type
    uint8 headway_valid
    float32 headway
    uint8 lanes_on
    uint8 left_ldw_on
    uint8 right_ldw_on
    uint8 fcw_on
    uint8 left_cross
    uint8 right_cross
    uint8 maintenance
    uint8 fail_safe
    uint8 ped_fcw
    uint8 ped_in_dz
    uint8 warning_level
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    string frame_id
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new AWSDisplay(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.night_time !== undefined) {
      resolved.night_time = msg.night_time;
    }
    else {
      resolved.night_time = 0
    }

    if (msg.dusk_time !== undefined) {
      resolved.dusk_time = msg.dusk_time;
    }
    else {
      resolved.dusk_time = 0
    }

    if (msg.sound_type !== undefined) {
      resolved.sound_type = msg.sound_type;
    }
    else {
      resolved.sound_type = 0
    }

    if (msg.headway_valid !== undefined) {
      resolved.headway_valid = msg.headway_valid;
    }
    else {
      resolved.headway_valid = 0
    }

    if (msg.headway !== undefined) {
      resolved.headway = msg.headway;
    }
    else {
      resolved.headway = 0.0
    }

    if (msg.lanes_on !== undefined) {
      resolved.lanes_on = msg.lanes_on;
    }
    else {
      resolved.lanes_on = 0
    }

    if (msg.left_ldw_on !== undefined) {
      resolved.left_ldw_on = msg.left_ldw_on;
    }
    else {
      resolved.left_ldw_on = 0
    }

    if (msg.right_ldw_on !== undefined) {
      resolved.right_ldw_on = msg.right_ldw_on;
    }
    else {
      resolved.right_ldw_on = 0
    }

    if (msg.fcw_on !== undefined) {
      resolved.fcw_on = msg.fcw_on;
    }
    else {
      resolved.fcw_on = 0
    }

    if (msg.left_cross !== undefined) {
      resolved.left_cross = msg.left_cross;
    }
    else {
      resolved.left_cross = 0
    }

    if (msg.right_cross !== undefined) {
      resolved.right_cross = msg.right_cross;
    }
    else {
      resolved.right_cross = 0
    }

    if (msg.maintenance !== undefined) {
      resolved.maintenance = msg.maintenance;
    }
    else {
      resolved.maintenance = 0
    }

    if (msg.fail_safe !== undefined) {
      resolved.fail_safe = msg.fail_safe;
    }
    else {
      resolved.fail_safe = 0
    }

    if (msg.ped_fcw !== undefined) {
      resolved.ped_fcw = msg.ped_fcw;
    }
    else {
      resolved.ped_fcw = 0
    }

    if (msg.ped_in_dz !== undefined) {
      resolved.ped_in_dz = msg.ped_in_dz;
    }
    else {
      resolved.ped_in_dz = 0
    }

    if (msg.warning_level !== undefined) {
      resolved.warning_level = msg.warning_level;
    }
    else {
      resolved.warning_level = 0
    }

    return resolved;
    }
};

module.exports = AWSDisplay;
