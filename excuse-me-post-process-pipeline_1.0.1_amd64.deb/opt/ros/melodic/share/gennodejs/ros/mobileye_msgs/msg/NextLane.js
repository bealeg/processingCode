// Auto-generated. Do not edit!

// (in-package mobileye_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let NextLaneObject = require('./NextLaneObject.js');
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class NextLane {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.number_of_nextlane = null;
      this.nextlaneobjects = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('number_of_nextlane')) {
        this.number_of_nextlane = initObj.number_of_nextlane
      }
      else {
        this.number_of_nextlane = 0;
      }
      if (initObj.hasOwnProperty('nextlaneobjects')) {
        this.nextlaneobjects = initObj.nextlaneobjects
      }
      else {
        this.nextlaneobjects = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type NextLane
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [number_of_nextlane]
    bufferOffset = _serializer.uint8(obj.number_of_nextlane, buffer, bufferOffset);
    // Serialize message field [nextlaneobjects]
    // Serialize the length for message field [nextlaneobjects]
    bufferOffset = _serializer.uint32(obj.nextlaneobjects.length, buffer, bufferOffset);
    obj.nextlaneobjects.forEach((val) => {
      bufferOffset = NextLaneObject.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type NextLane
    let len;
    let data = new NextLane(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [number_of_nextlane]
    data.number_of_nextlane = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [nextlaneobjects]
    // Deserialize array length for message field [nextlaneobjects]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.nextlaneobjects = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.nextlaneobjects[i] = NextLaneObject.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    object.nextlaneobjects.forEach((val) => {
      length += NextLaneObject.getMessageSize(val);
    });
    return length + 5;
  }

  static datatype() {
    // Returns string type for a message object
    return 'mobileye_msgs/NextLane';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'bde1b2cd28f72618d147c28f1960a071';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    #Message Header
    std_msgs/Header header
    
    uint8 number_of_nextlane #0 - 4
    
    NextLaneObject[] nextlaneobjects
    
     
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    string frame_id
    
    ================================================================================
    MSG: mobileye_msgs/NextLaneObject
    #Message Header
    std_msgs/Header header
    
    uint8 left_lane_type  #1=solid 2=undecided
    uint8 left_model_degree  #1=linear_model, 2=parabolic_model, 3=3rd_degree_model
    float64 left_C0 #m  [-127,128]
    float64 left_C1 #[-0.357 - 0.357]
    float64 left_C2 #[-0.02 -  0.02]
    float64 left_C3 #[-0.00012 -  0.00012]
    uint8 left_view_availability #0=not_valid, 1=valid
    
    uint8 right_lane_type  #1=solid 2=undecided
    uint8 right_model_degree  #1=linear_model, 2=parabolic_model, 3=3rd_degree_model
    float64 right_C0 #m  [-127,128]
    float64 right_C1 #[-0.357 - 0.357]
    float64 right_C2 #[-0.02 -  0.02]
    float64 right_C3 #[-0.00012 -  0.00012]
    uint8 right_view_availability #0=not_valid, 1=valid
    
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new NextLane(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.number_of_nextlane !== undefined) {
      resolved.number_of_nextlane = msg.number_of_nextlane;
    }
    else {
      resolved.number_of_nextlane = 0
    }

    if (msg.nextlaneobjects !== undefined) {
      resolved.nextlaneobjects = new Array(msg.nextlaneobjects.length);
      for (let i = 0; i < resolved.nextlaneobjects.length; ++i) {
        resolved.nextlaneobjects[i] = NextLaneObject.Resolve(msg.nextlaneobjects[i]);
      }
    }
    else {
      resolved.nextlaneobjects = []
    }

    return resolved;
    }
};

module.exports = NextLane;
