// Auto-generated. Do not edit!

// (in-package mobileye_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let TSR = require('./TSR.js');
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class TSRs {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.number_of_tsrs = null;
      this.tsrs = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('number_of_tsrs')) {
        this.number_of_tsrs = initObj.number_of_tsrs
      }
      else {
        this.number_of_tsrs = 0;
      }
      if (initObj.hasOwnProperty('tsrs')) {
        this.tsrs = initObj.tsrs
      }
      else {
        this.tsrs = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type TSRs
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [number_of_tsrs]
    bufferOffset = _serializer.uint8(obj.number_of_tsrs, buffer, bufferOffset);
    // Serialize message field [tsrs]
    // Serialize the length for message field [tsrs]
    bufferOffset = _serializer.uint32(obj.tsrs.length, buffer, bufferOffset);
    obj.tsrs.forEach((val) => {
      bufferOffset = TSR.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type TSRs
    let len;
    let data = new TSRs(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [number_of_tsrs]
    data.number_of_tsrs = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [tsrs]
    // Deserialize array length for message field [tsrs]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.tsrs = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.tsrs[i] = TSR.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    object.tsrs.forEach((val) => {
      length += TSR.getMessageSize(val);
    });
    return length + 5;
  }

  static datatype() {
    // Returns string type for a message object
    return 'mobileye_msgs/TSRs';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '11c82a4097b1421d90e062d04deca5b7';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    #Message Header
    std_msgs/Header header
    
    uint8 number_of_tsrs
    
    TSR[] tsrs
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    string frame_id
    
    ================================================================================
    MSG: mobileye_msgs/TSR
    #Message Header
    std_msgs/Header header
    
    uint8 type
    uint8 supplementary_type
    float32 pos_x
    float32 pos_y
    float32 pos_z
    uint8 filter_type
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new TSRs(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.number_of_tsrs !== undefined) {
      resolved.number_of_tsrs = msg.number_of_tsrs;
    }
    else {
      resolved.number_of_tsrs = 0
    }

    if (msg.tsrs !== undefined) {
      resolved.tsrs = new Array(msg.tsrs.length);
      for (let i = 0; i < resolved.tsrs.length; ++i) {
        resolved.tsrs[i] = TSR.Resolve(msg.tsrs[i]);
      }
    }
    else {
      resolved.tsrs = []
    }

    return resolved;
    }
};

module.exports = TSRs;
