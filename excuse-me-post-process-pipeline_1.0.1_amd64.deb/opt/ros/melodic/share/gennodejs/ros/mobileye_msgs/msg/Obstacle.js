// Auto-generated. Do not edit!

// (in-package mobileye_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let ObstacleObject = require('./ObstacleObject.js');
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class Obstacle {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.number_of_obstacles = null;
      this.close_car = null;
      this.objects = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('number_of_obstacles')) {
        this.number_of_obstacles = initObj.number_of_obstacles
      }
      else {
        this.number_of_obstacles = 0;
      }
      if (initObj.hasOwnProperty('close_car')) {
        this.close_car = initObj.close_car
      }
      else {
        this.close_car = 0;
      }
      if (initObj.hasOwnProperty('objects')) {
        this.objects = initObj.objects
      }
      else {
        this.objects = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type Obstacle
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [number_of_obstacles]
    bufferOffset = _serializer.uint8(obj.number_of_obstacles, buffer, bufferOffset);
    // Serialize message field [close_car]
    bufferOffset = _serializer.uint8(obj.close_car, buffer, bufferOffset);
    // Serialize message field [objects]
    // Serialize the length for message field [objects]
    bufferOffset = _serializer.uint32(obj.objects.length, buffer, bufferOffset);
    obj.objects.forEach((val) => {
      bufferOffset = ObstacleObject.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type Obstacle
    let len;
    let data = new Obstacle(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [number_of_obstacles]
    data.number_of_obstacles = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [close_car]
    data.close_car = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [objects]
    // Deserialize array length for message field [objects]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.objects = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.objects[i] = ObstacleObject.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    object.objects.forEach((val) => {
      length += ObstacleObject.getMessageSize(val);
    });
    return length + 6;
  }

  static datatype() {
    // Returns string type for a message object
    return 'mobileye_msgs/Obstacle';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '7c93b1efc5f706e125df47e72a0ca0fb';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    #Message Header
    std_msgs/Header header
    
    uint8 number_of_obstacles #0 - 255
    uint8 close_car #indicates whether we deted a close car in front of host vehicle
    
    ObstacleObject[] objects
    
     
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    string frame_id
    
    ================================================================================
    MSG: mobileye_msgs/ObstacleObject
    #Message Header
    std_msgs/Header header
    
    uint8 id # id
    uint8 age # in frames 0 - 254, 254 is oldest
    uint8 valid # 1=new valid, 2=older valid
    uint8 status # 0=undefined,1=standing,2=stopped,3=moving,4=oncoming,5=parked
    uint8 lane_status # 0=undefined,1=in_host_lane,2=out_host_lane,3=cut_in,4=cut_out
    uint8 lane #0=not_assigned,1=ego_lane,2=next_lane(left or right), or next_next_lane,3=invalid
    uint8 type # 0=vehicle,1=truck,2=bike,3=ped,4=bicycle
    uint8 brake_light #0=off,1=on
    uint8 blinker # 0=unavailable,1=off,2=left,3=right,4=both
    uint8 cipv #closest_in_path_vehicle 0=no,1=yes
    uint8 replaced #0=not_replaced_in_this_frame,1=replaced_in_this_frame
    
    float64 x_pos #m
    float64 y_pos #m
    float64 x_vel #m/s
    
    float64 angle_rate #deg/s
    float64 scale_change #pix/s
    float64 x_accel #m/s^2
    
    float64 angle #deg
    
    
    float64 length #m
    float64 width #m
    
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new Obstacle(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.number_of_obstacles !== undefined) {
      resolved.number_of_obstacles = msg.number_of_obstacles;
    }
    else {
      resolved.number_of_obstacles = 0
    }

    if (msg.close_car !== undefined) {
      resolved.close_car = msg.close_car;
    }
    else {
      resolved.close_car = 0
    }

    if (msg.objects !== undefined) {
      resolved.objects = new Array(msg.objects.length);
      for (let i = 0; i < resolved.objects.length; ++i) {
        resolved.objects[i] = ObstacleObject.Resolve(msg.objects[i]);
      }
    }
    else {
      resolved.objects = []
    }

    return resolved;
    }
};

module.exports = Obstacle;
