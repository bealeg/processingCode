// Auto-generated. Do not edit!

// (in-package mobileye_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class NextLaneObject {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.left_lane_type = null;
      this.left_model_degree = null;
      this.left_C0 = null;
      this.left_C1 = null;
      this.left_C2 = null;
      this.left_C3 = null;
      this.left_view_availability = null;
      this.right_lane_type = null;
      this.right_model_degree = null;
      this.right_C0 = null;
      this.right_C1 = null;
      this.right_C2 = null;
      this.right_C3 = null;
      this.right_view_availability = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('left_lane_type')) {
        this.left_lane_type = initObj.left_lane_type
      }
      else {
        this.left_lane_type = 0;
      }
      if (initObj.hasOwnProperty('left_model_degree')) {
        this.left_model_degree = initObj.left_model_degree
      }
      else {
        this.left_model_degree = 0;
      }
      if (initObj.hasOwnProperty('left_C0')) {
        this.left_C0 = initObj.left_C0
      }
      else {
        this.left_C0 = 0.0;
      }
      if (initObj.hasOwnProperty('left_C1')) {
        this.left_C1 = initObj.left_C1
      }
      else {
        this.left_C1 = 0.0;
      }
      if (initObj.hasOwnProperty('left_C2')) {
        this.left_C2 = initObj.left_C2
      }
      else {
        this.left_C2 = 0.0;
      }
      if (initObj.hasOwnProperty('left_C3')) {
        this.left_C3 = initObj.left_C3
      }
      else {
        this.left_C3 = 0.0;
      }
      if (initObj.hasOwnProperty('left_view_availability')) {
        this.left_view_availability = initObj.left_view_availability
      }
      else {
        this.left_view_availability = 0;
      }
      if (initObj.hasOwnProperty('right_lane_type')) {
        this.right_lane_type = initObj.right_lane_type
      }
      else {
        this.right_lane_type = 0;
      }
      if (initObj.hasOwnProperty('right_model_degree')) {
        this.right_model_degree = initObj.right_model_degree
      }
      else {
        this.right_model_degree = 0;
      }
      if (initObj.hasOwnProperty('right_C0')) {
        this.right_C0 = initObj.right_C0
      }
      else {
        this.right_C0 = 0.0;
      }
      if (initObj.hasOwnProperty('right_C1')) {
        this.right_C1 = initObj.right_C1
      }
      else {
        this.right_C1 = 0.0;
      }
      if (initObj.hasOwnProperty('right_C2')) {
        this.right_C2 = initObj.right_C2
      }
      else {
        this.right_C2 = 0.0;
      }
      if (initObj.hasOwnProperty('right_C3')) {
        this.right_C3 = initObj.right_C3
      }
      else {
        this.right_C3 = 0.0;
      }
      if (initObj.hasOwnProperty('right_view_availability')) {
        this.right_view_availability = initObj.right_view_availability
      }
      else {
        this.right_view_availability = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type NextLaneObject
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [left_lane_type]
    bufferOffset = _serializer.uint8(obj.left_lane_type, buffer, bufferOffset);
    // Serialize message field [left_model_degree]
    bufferOffset = _serializer.uint8(obj.left_model_degree, buffer, bufferOffset);
    // Serialize message field [left_C0]
    bufferOffset = _serializer.float64(obj.left_C0, buffer, bufferOffset);
    // Serialize message field [left_C1]
    bufferOffset = _serializer.float64(obj.left_C1, buffer, bufferOffset);
    // Serialize message field [left_C2]
    bufferOffset = _serializer.float64(obj.left_C2, buffer, bufferOffset);
    // Serialize message field [left_C3]
    bufferOffset = _serializer.float64(obj.left_C3, buffer, bufferOffset);
    // Serialize message field [left_view_availability]
    bufferOffset = _serializer.uint8(obj.left_view_availability, buffer, bufferOffset);
    // Serialize message field [right_lane_type]
    bufferOffset = _serializer.uint8(obj.right_lane_type, buffer, bufferOffset);
    // Serialize message field [right_model_degree]
    bufferOffset = _serializer.uint8(obj.right_model_degree, buffer, bufferOffset);
    // Serialize message field [right_C0]
    bufferOffset = _serializer.float64(obj.right_C0, buffer, bufferOffset);
    // Serialize message field [right_C1]
    bufferOffset = _serializer.float64(obj.right_C1, buffer, bufferOffset);
    // Serialize message field [right_C2]
    bufferOffset = _serializer.float64(obj.right_C2, buffer, bufferOffset);
    // Serialize message field [right_C3]
    bufferOffset = _serializer.float64(obj.right_C3, buffer, bufferOffset);
    // Serialize message field [right_view_availability]
    bufferOffset = _serializer.uint8(obj.right_view_availability, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type NextLaneObject
    let len;
    let data = new NextLaneObject(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [left_lane_type]
    data.left_lane_type = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [left_model_degree]
    data.left_model_degree = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [left_C0]
    data.left_C0 = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [left_C1]
    data.left_C1 = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [left_C2]
    data.left_C2 = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [left_C3]
    data.left_C3 = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [left_view_availability]
    data.left_view_availability = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [right_lane_type]
    data.right_lane_type = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [right_model_degree]
    data.right_model_degree = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [right_C0]
    data.right_C0 = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [right_C1]
    data.right_C1 = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [right_C2]
    data.right_C2 = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [right_C3]
    data.right_C3 = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [right_view_availability]
    data.right_view_availability = _deserializer.uint8(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    return length + 70;
  }

  static datatype() {
    // Returns string type for a message object
    return 'mobileye_msgs/NextLaneObject';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '9403e1d4f874de61d005fd3e2b982cf1';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    #Message Header
    std_msgs/Header header
    
    uint8 left_lane_type  #1=solid 2=undecided
    uint8 left_model_degree  #1=linear_model, 2=parabolic_model, 3=3rd_degree_model
    float64 left_C0 #m  [-127,128]
    float64 left_C1 #[-0.357 - 0.357]
    float64 left_C2 #[-0.02 -  0.02]
    float64 left_C3 #[-0.00012 -  0.00012]
    uint8 left_view_availability #0=not_valid, 1=valid
    
    uint8 right_lane_type  #1=solid 2=undecided
    uint8 right_model_degree  #1=linear_model, 2=parabolic_model, 3=3rd_degree_model
    float64 right_C0 #m  [-127,128]
    float64 right_C1 #[-0.357 - 0.357]
    float64 right_C2 #[-0.02 -  0.02]
    float64 right_C3 #[-0.00012 -  0.00012]
    uint8 right_view_availability #0=not_valid, 1=valid
    
    
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    string frame_id
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new NextLaneObject(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.left_lane_type !== undefined) {
      resolved.left_lane_type = msg.left_lane_type;
    }
    else {
      resolved.left_lane_type = 0
    }

    if (msg.left_model_degree !== undefined) {
      resolved.left_model_degree = msg.left_model_degree;
    }
    else {
      resolved.left_model_degree = 0
    }

    if (msg.left_C0 !== undefined) {
      resolved.left_C0 = msg.left_C0;
    }
    else {
      resolved.left_C0 = 0.0
    }

    if (msg.left_C1 !== undefined) {
      resolved.left_C1 = msg.left_C1;
    }
    else {
      resolved.left_C1 = 0.0
    }

    if (msg.left_C2 !== undefined) {
      resolved.left_C2 = msg.left_C2;
    }
    else {
      resolved.left_C2 = 0.0
    }

    if (msg.left_C3 !== undefined) {
      resolved.left_C3 = msg.left_C3;
    }
    else {
      resolved.left_C3 = 0.0
    }

    if (msg.left_view_availability !== undefined) {
      resolved.left_view_availability = msg.left_view_availability;
    }
    else {
      resolved.left_view_availability = 0
    }

    if (msg.right_lane_type !== undefined) {
      resolved.right_lane_type = msg.right_lane_type;
    }
    else {
      resolved.right_lane_type = 0
    }

    if (msg.right_model_degree !== undefined) {
      resolved.right_model_degree = msg.right_model_degree;
    }
    else {
      resolved.right_model_degree = 0
    }

    if (msg.right_C0 !== undefined) {
      resolved.right_C0 = msg.right_C0;
    }
    else {
      resolved.right_C0 = 0.0
    }

    if (msg.right_C1 !== undefined) {
      resolved.right_C1 = msg.right_C1;
    }
    else {
      resolved.right_C1 = 0.0
    }

    if (msg.right_C2 !== undefined) {
      resolved.right_C2 = msg.right_C2;
    }
    else {
      resolved.right_C2 = 0.0
    }

    if (msg.right_C3 !== undefined) {
      resolved.right_C3 = msg.right_C3;
    }
    else {
      resolved.right_C3 = 0.0
    }

    if (msg.right_view_availability !== undefined) {
      resolved.right_view_availability = msg.right_view_availability;
    }
    else {
      resolved.right_view_availability = 0
    }

    return resolved;
    }
};

module.exports = NextLaneObject;
